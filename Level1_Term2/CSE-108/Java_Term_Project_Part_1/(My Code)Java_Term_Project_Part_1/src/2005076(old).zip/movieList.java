import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class movieList{

    private static final String INPUT_FILE_NAME = "movies.txt";
    private static final String OUTPUT_FILE_NAME = "movies.txt";

    private static String title, genre1, genre2, genre3, production_company;
    private static int year, runTime, budget;
    private static long revenue;

    private static final List<Movie> MovieList = new ArrayList<>();

    public static void main(String[] args) throws Exception {

        BufferedReader bufferedReader = new BufferedReader(new FileReader(INPUT_FILE_NAME));

        while(true) {
            String single_line = bufferedReader.readLine();
            if (single_line == null) break;

            String[] single_word = single_line.split(",");
            title = single_word[0];
            year = Integer.parseInt(single_word[1]);
            genre1 = single_word[2];
            genre2 = single_word[3];
            genre3 = single_word[4];
            runTime = Integer.parseInt(single_word[5]);
            production_company = single_word[6];
            budget = Integer.parseInt(single_word[7]);
            revenue = Long.parseLong(single_word[8]);

            Movie movie = new Movie(title, year, genre1, genre2, genre3, runTime, production_company, budget, revenue);
            MovieList.add(movie);
        }
        bufferedReader.close();

        Main_Menu();


    }
    private static void Main_Menu(){

        while(true){
            System.out.println();
            System.out.println("\t\tMain Menu:");
            System.out.println("\t\t1) Search Movies");
            System.out.println("\t\t2) Search Production Companies");
            System.out.println("\t\t3) Add Movie");
            System.out.println("\t\t4) Exit System");
            System.out.println();
            System.out.print("\t\t");

            Scanner scan = new Scanner(System.in);
            if(!scan.hasNextInt()){
                System.out.println("\t\t!! Invalid Input. Please Enter the number 1-4 !!");
                continue;
            }
            int option = scan.nextInt();

            if(option==1) searchMovies();
            else if(option==2) searchProduction_Company();
            else if(option==3) addMovie();
            else if(option==4) {
                System.out.println();
                System.out.println("\t\t\t---Successfully Exited the Program...Thank You---");
                System.out.println();
                try {
                    exitSystem();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
                break;
            }
            else
                System.out.println("\t\t!! Invalid Input. Please Enter the number 1-4 !!");

        }
    }
    private static void searchMovies(){
        while(true){
            System.out.println();
            System.out.println("\t\tMovie Searching Options:");
            System.out.println("\t\t1) By Movie Title");
            System.out.println("\t\t2) By Release Year");
            System.out.println("\t\t3) By Genre");
            System.out.println("\t\t4) By Production Company");
            System.out.println("\t\t5) By Running Time");
            System.out.println("\t\t6) Top 10 Movies");
            System.out.println("\t\t7) Back to Main Menu");
            System.out.println();
            System.out.print("\t\t");

            Scanner scan = new Scanner(System.in);
            if(!scan.hasNextInt()){
                System.out.println("\t\t!! Invalid Input. Please Enter the number 1-7 !!");
                continue;
            }
            int option = scan.nextInt();

            if(option==1) search_By_Title();
            else if(option==2) search_By_ReleaseYear();
            else if(option==3) search_By_Genre();
            else if(option==4) search_BY_ProductionCompany();
            else if(option==5) search_BY_RunTime();
            else if(option==6) Top_10_Movies();
            else if(option==7) break;
            else
                System.out.println("\t\t!! Invalid Input. Please Enter the number 1-7 !!");
        }
    }

    private static void searchProduction_Company(){
        while(true){
            System.out.println();
            System.out.println("\t\tProduction Company Searching Options:");
            System.out.println("\t\t1) Most Recent Movies");
            System.out.println("\t\t2) Movies with the Maximum Revenue");
            System.out.println("\t\t3) Total Profit");
            System.out.println("\t\t4) List of Production Companies and the Count of their Produced Movies");
            System.out.println("\t\t5) Back to Main Menu");
            System.out.println();
            System.out.print("\t\t");

            Scanner scan = new Scanner(System.in);
            if(!scan.hasNextInt()){
                System.out.println("\t\t!! Invalid Input. Please Enter the number 1-5 !!");
                continue;
            }
            int option = scan.nextInt();

            if(option==1) search_By_MostRecent();
            else if(option==2) search_By_MaximumRevenue();
            else if(option==3) search_for_TotalProfit();
            else if(option==4) List_of_ProductionCompanies();
            else if(option==5) break;
            else
                System.out.println("\t\t!! Invalid Input. Please Enter the number 1-5 !!");
        }
    }

    private static void addMovie(){
        System.out.println();
        System.out.println("\tPlease enter the details of the Movie that you want to add:");
        System.out.println();
        Scanner scan = new Scanner(System.in);

        System.out.println("\t\tEnter the Name of the movie:");
        System.out.print("\t\t");
        title = scan.nextLine();
        for(Movie mvi : MovieList){
            if(mvi.getTitle().equalsIgnoreCase(title)){
                System.out.println();
                System.out.println("\t\t!! Error, this movie already exists in the List !! ");
                return;
            }
        }

        System.out.println("\t\tEnter the Release Year:");
        System.out.print("\t\t");
        year = scan.nextInt();

        System.out.println("\t\tEnter the Genres of the movie (Please follow the format: Genre1,Genre2,Genre3) you can use SPACE in place of Genre2 and Genre3 :");
        System.out.print("\t\t");
        Scanner newScan = new Scanner(System.in);
        String genres = newScan.nextLine();
        String[] genre = genres.split(",");
        genre1 = genre[0];
        genre2 = genre[1];
        genre3 = genre [2];

        System.out.println("\t\tEnter the Run Time of the movie (in minute):");
        System.out.print("\t\t");
        runTime = scan.nextInt();

        System.out.println("\t\tEnter the Production Company:");
        System.out.print("\t\t");
        Scanner newScan2 = new Scanner(System.in);
        production_company = newScan2.nextLine();

        System.out.println("\t\tEnter the Budget of the movie:");
        System.out.print("\t\t");
        budget = scan.nextInt();

        System.out.println("\t\tEnter the Revenue of the movie:");
        System.out.print("\t\t");
        revenue = scan.nextLong();
        System.out.println();

        Movie movie = new Movie(title, year, genre1, genre2, genre3, runTime, production_company, budget, revenue);
        MovieList.add(movie);

        System.out.println("\t\tMovie has been perfectly added....Exit the program successfully to save it to the file");
    }

    private static void exitSystem() throws Exception{

        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(OUTPUT_FILE_NAME));
        for (Movie mvi : MovieList) {
            bufferedWriter.write(mvi.movieDetails());
            bufferedWriter.write(System.lineSeparator());
        }
        bufferedWriter.close();
    }


        //--------------------Implementing (1) Search Movies_functions----------------------//

    private static void search_By_Title(){
        int flag=0;
        System.out.println();
        System.out.println("\tEnter the Movie name you want to search:");
        System.out.print("\t");
        Scanner scan = new Scanner(System.in);
        String movie = scan.nextLine();
        System.out.println();
        for (Movie value : MovieList) {
            if (value.getTitle().equalsIgnoreCase(movie)) {
                System.out.println("\t\tThe details of your searched Movie:");
                value.printMovie_Details();
                flag = 1;
                break;
            }
        }
        if(flag==0)
            System.out.println("\t\tNo such movie with this name!");
    }
    private static void search_By_ReleaseYear(){
        int flag=0;
        System.out.println();
        System.out.println("\tEnter the Released Year of the movies you want to see:");
        System.out.print("\t");
        Scanner scan = new Scanner(System.in);
        int year = scan.nextInt();
        System.out.println();
        for (Movie movie : MovieList) {
            if (year == movie.getYear_of_Release()) {
                if (flag == 0)
                    System.out.println("\t\tIn the year " + year + " these movies had been released:");
                movie.printMovie_Details();
                flag = 1;
            }
        }
        if(flag==0)
            System.out.println("\t\tNo such movie with this release year!");
    }
    private static void search_By_Genre(){
        int flag=0;
        System.out.println();
        System.out.println("\tThe Genre of the movies you want to see:");
        System.out.print("\t");
        Scanner scan = new Scanner(System.in);
        String genre = scan.nextLine();
        System.out.println();
        for (Movie movie : MovieList) {
            if (movie.getGenre1().equalsIgnoreCase(genre) || movie.getGenre2().equalsIgnoreCase(genre) || movie.getGenre3().equalsIgnoreCase(genre)) {
                if (flag == 0)
                    System.out.println("\t\tWe have movies for Genre " + genre + ":");
                movie.printMovie_Details();
                flag = 1;
            }
        }
        if(flag==0)
            System.out.println("\t\tNo such movie with this genre!");
    }
    private static void search_BY_ProductionCompany(){
        int flag=0;
        System.out.println();
        System.out.println("\tEnter a particular Production Company to see it's produced movies:");
        System.out.print("\t");
        Scanner scan = new Scanner(System.in);
        String productionCom = scan.nextLine();
        System.out.println();
        for (Movie movie : MovieList) {
            if (movie.getProduction_Company().equalsIgnoreCase(productionCom)) {
                if (flag == 0)
                    System.out.println("\t\tThe production company " + movie.getProduction_Company() + " has produced these movies:");
                movie.printMovie_Details();
                flag = 1;
            }
        }
        if(flag==0)
            System.out.println("\t\tNo such movie with this production company!");
    }
    private static void search_BY_RunTime(){
        int flag=0;
        System.out.println();
        System.out.println("\tEnter a range of Run-Time to see the movies in this range(in minute):");
        System.out.print("\t");
        Scanner scan = new Scanner(System.in);
        int initialTime = scan.nextInt();
        int finalTime = scan.nextInt();
        System.out.println();
        for (Movie movie : MovieList) {
            if (movie.getRunning_Time() >= initialTime && movie.getRunning_Time() <= finalTime) {
                if (flag == 0)
                    System.out.println("\t\tThe movies whose run time in the range " + initialTime + "-" + finalTime + " :");
                movie.printMovie_Details();
                flag = 1;
            }
        }
        if(flag==0)
            System.out.println("\t\tNo such movie with this running time range!");
    }
    private static void Top_10_Movies(){
        int n = 10;
        Movie[] topMovies = new Movie[n];
        long maxProfit=0;
        int index = 0;
        System.out.println();
        System.out.println("\t\tDisplaying TOP 10 MOVIES (based on profit):");
        for(int i=0; i<MovieList.size(); i++){
            if(MovieList.get(i).getProfit() > maxProfit){
                maxProfit = MovieList.get(i).getProfit();
                index = i;
            }
        }
        topMovies[0] = MovieList.get(index);
        for(int i=1; i<n; i++){
            maxProfit = 0;
            for(int j=0; j<MovieList.size(); j++){
                if(MovieList.get(j).getProfit() < topMovies[i-1].getProfit() && MovieList.get(j).getProfit() > maxProfit){
                    maxProfit = MovieList.get(j).getProfit();
                    index = j;
                }
            }
            topMovies[i] = MovieList.get(index);
        }
        for(int i = 0; i<n; i++)
            topMovies[i].printMovie_Details();
    }



        //------------------Implementing (2) Search Production Companies_functions--------------------//


    private static void search_By_MostRecent(){
        int flag=0;
        System.out.println();
        System.out.println("\tEnter a particular Production Company to see it's most recent produced movie:");
        System.out.print("\t");
        Scanner scan = new Scanner(System.in);
        String productionCom = scan.nextLine();
        System.out.println();
        int recentYear = 0;
        for (Movie mvi : MovieList) {
            if (mvi.getProduction_Company().equalsIgnoreCase(productionCom) && mvi.getYear_of_Release() > recentYear) {
                if (flag == 0)
                    System.out.println("\t\tThe Latest  Movie of the production company " +mvi.getProduction_Company() + " :");
                recentYear = mvi.getYear_of_Release();
                flag = 1;
            }
        }
        if(flag==1){
            for (Movie movie : MovieList) {
                if (movie.getProduction_Company().equalsIgnoreCase(productionCom) && movie.getYear_of_Release() == recentYear) {
                    movie.printMovie_Details();
                }
            }
        }
        else System.out.println("\t\tNo such production company with this name!");
    }

    private static void search_By_MaximumRevenue(){
        int flag=0;
        System.out.println();
        System.out.println("\tEnter a particular Production Company to see it's Highest Grossed produced movie:");
        System.out.print("\t");
        Scanner scan = new Scanner(System.in);
        String productionCom = scan.nextLine();
        System.out.println();
        long maxRevenue = 0;
        for (Movie value : MovieList) {
            if (value.getProduction_Company().equalsIgnoreCase(productionCom) && value.getRevenue() > maxRevenue) {
                if (flag == 0)
                    System.out.println("\t\tThe Highest Grossed Movie of the production company " + value.getProduction_Company() + " :");
                maxRevenue = value.getRevenue();
                flag = 1;
            }
        }
        if(flag==1){
            for (Movie movie : MovieList) {
                if (movie.getProduction_Company().equalsIgnoreCase(productionCom) && movie.getRevenue() == maxRevenue) {
                    movie.printMovie_Details();
                }
            }
        }
        else System.out.println("\t\tNo such production company with this name!");
    }

    private static void search_for_TotalProfit(){
        int flag=0;
        System.out.println();
        System.out.println("\tEnter a particular Production Company to see it's total profit (or loss):");
        System.out.print("\t");
        Scanner scan = new Scanner(System.in);
        String productionCom = scan.nextLine();
        System.out.println();
        long sumProfit = 0;
        for (Movie movie : MovieList) {
            if (movie.getProduction_Company().equalsIgnoreCase(productionCom)) {
                sumProfit += movie.getProfit();
                flag = 1;
            }
        }
        if(flag==1){
            if(sumProfit >= 0){
                System.out.println("\t\tThe total Profit of the production company "+productionCom+" : "+sumProfit+" $");
            }
            else
                System.out.println("\t\tThe total Loss of the production company "+productionCom+" : "+(-sumProfit)+" $");
        }
        else System.out.println("\t\tNo such production company with this name!");
    }

    public static void List_of_ProductionCompanies(){
        int k=1;
        System.out.println();
        System.out.println("\tDisplaying all the Production Company and the number of movies they have produced:");
        System.out.println();
        List<String> pcList = new ArrayList<>();
        int[] count = new int[MovieList.size()];
        for(int i =0; i< MovieList.size(); i++){
            pcList.add(MovieList.get(i).getProduction_Company());
            count[i] = 1;
        }

        for(int i =0; i<pcList.size(); i++){
            for(int j = i+1; j<pcList.size(); j++){
                if(pcList.get(j).equalsIgnoreCase(pcList.get(i))){
                    count[i]++;
                    count[j] = -1000;
                }
            }
        }
        for(int i = 0; i<pcList.size(); i++){
            if(count[i]>0){
                System.out.println("\t\t"+k+") "+pcList.get(i)+", Number of produced movie: "+count[i]);
                k++;
            }
        }
    }
}


     //-------------------------------------------!!COMPLETED!!--------------------------------------------//


             //Sorting all movies according to their release year for a particular Production Company

 //private static void sort_By_MostRecent(){
 //    int flag=0;
 //    System.out.println();
 //    System.out.println("\tEnter a particular Production Company to see it's most recent produced movies:");
 //    System.out.print("\t");
 //    Scanner scan = new Scanner(System.in);
 //    String productionCom = scan.nextLine();
 //    System.out.println();
 //    List<Movie> Recent_movieList = new ArrayList<>();
 //    for (Movie movie : MovieList) {
 //        if (movie.getProduction_Company().equalsIgnoreCase(productionCom)) {
 //            if (flag == 0)
 //                System.out.println("\t\tThe latest Movies of the production company " + movie.getProduction_Company() + " according to their released year:");
 //            Recent_movieList.add(movie);
 //            flag = 1;
 //        }
 //    }
 //    if(flag==1){
 //        Movie[] recentMovies = new Movie[Recent_movieList.size()];
 //        int recentYear = 0;
 //        int index = 0;
 //        for(int i=0; i<Recent_movieList.size(); i++){
 //            if(Recent_movieList.get(i).getYear_of_Release() > recentYear){
 //                recentYear = Recent_movieList.get(i).getYear_of_Release();
 //                index = i;
 //            }
 //        }
 //        recentMovies[0] = Recent_movieList.get(index);
 //        for(int i=1; i<Recent_movieList.size(); i++){
 //            recentYear = 0;
 //            for(int j=0; j<Recent_movieList.size(); j++){
 //                if(Recent_movieList.get(j).getYear_of_Release() < recentMovies[i-1].getYear_of_Release() && Recent_movieList.get(j).getYear_of_Release() > recentYear){
 //                    recentYear = Recent_movieList.get(j).getYear_of_Release();
 //                    index = j;
 //                }
 //            }
 //            recentMovies[i] = Recent_movieList.get(index);
 //        }
 //        for(int i = 0; i<Recent_movieList.size(); i++)
 //            recentMovies[i].printMovie_Details();
 //    }
 //    else System.out.println("\t\tNo such production company with this name!");
 //}