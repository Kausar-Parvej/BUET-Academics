import numpy as np
import matplotlib.pyplot as plt


def graph(x_values, y_values):
    plt.close('all')
    plt.plot(x_values, y_values, "o", label="Point Plot")

    plt.grid()
    plt.show()


if __name__ == '__main__':
    x_data = np.array([])
    y_data = np.array([])

    input_data = np.genfromtxt("input2.csv", delimiter=",", skip_header=1)
    # input_data = np.genfromtxt("input.txt", dtype=float, skip_header=1)
    for row in input_data:
        x_data = np.append(x_data, float(row[0]))
        y_data = np.append(y_data, float(row[1]))

    x_data = np.array([0.0, 5.0, 10.0, 15.0, 20.0, 25.0, 30.0])
    y_data = np.array([1000.0, 550.0, 316.0, 180.0, 85.0, 56.0, 31.0])

    graph(x_data, y_data)
