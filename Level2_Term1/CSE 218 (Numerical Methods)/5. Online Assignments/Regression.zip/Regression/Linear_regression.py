import numpy as np
import matplotlib.pyplot as plt


def graph(x_values, y_values, coeff):
    plt.close('all')
    plt.plot(x_values, y_values, "o")

    coefficient = np.copy(coeff)
    graph_x = np.linspace(-2, 12, 50)
    y2 = coefficient[0] + coefficient[1] * graph_x
    plt.plot(graph_x, y2, label="Linear Regression")
    plt.xlabel("x axis")
    plt.ylabel("y axis")

    plt.legend(loc="best")
    plt.grid()
    plt.show()


def linear_regression(a, b):
    x = np.copy(a)
    y = np.copy(b)
    n = np.size(a)

    mean_X = np.mean(x)
    mean_Y = np.mean(y)

    sum_X = np.sum(x)
    sum_Y = np.sum(y)
    sum_XY = np.sum(x * y)
    sum_XX = np.sum(x * x)

    a1 = (n * sum_XY - sum_X * sum_Y) / (n * sum_XX - sum_X * sum_X)
    a0 = mean_Y - a1 * mean_X

    return (a0, a1)


if __name__ == '__main__':
    x = np.array([])
    y = np.array([])

    # input_data = np.genfromtxt("input2.csv", delimiter=",", skip_header=1)
    input_data = np.genfromtxt("input.txt", dtype=float, skip_header=1)
    for row in input_data:
        x = np.append(x, float(row[0]))
        y = np.append(y, float(row[1]))

    co_eff = linear_regression(x, y)

    print("a0 = %f" % co_eff[0])
    print("a1 = %f" % co_eff[1])

    graph(x, y, co_eff)
