import sys

import numpy as np
import matplotlib.pyplot as plt


def gaussianElimination(A, B, pivot, showall):
    solution_matrix = np.zeros(n)
    step = 1
    for u in range(n):
        if pivot:
            max_index = u
            max_co = A[max_index][u]

            for ko in range(u + 1, n):
                if abs(A[ko][u]) > max_co:
                    max_index = ko
                    max_co = A[ko][u]

            if max_index != u:
                for ki in range(n):
                    temp = A[u][ki]
                    A[u][ki] = A[max_index][ki]
                    A[max_index][ki] = temp

                temp2 = B[u][0]
                B[u][0] = B[max_index][0]
                B[max_index][0] = temp2

        for v in range(u + 1, n):
            factor = A[v][u] / A[u][u]

            for w in range(u + 1, n):
                A[v][w] -= A[u][w] * factor
            B[v][0] -= B[u][0] * factor
            A[v][u] = 0

        if showall:
            print("Sub-Step %d:" % step)
            print(A)
            print()
            print(B)
            print()
            step += 1

    determinant = 1
    for it in range(n):
        determinant *= A[it][it]
    if showall:
        print('Determinant of the coefficient matrix is : %0.4f ' % determinant)
    if determinant == 0:
        sys.exit('ERROR! Infinite Solutions')

    for p in range(n - 1, -1, -1):
        solution_matrix[p] = B[p][0]

        for m in range(p + 1, n):
            solution_matrix[p] -= A[p][m] * solution_matrix[m]
        solution_matrix[p] = solution_matrix[p] / A[p][p]

    return solution_matrix


def graph(x_values, y_values, coeff):
    plt.close('all')
    plt.plot(x_values, y_values, "o")

    graph_x = np.linspace(1890, 2010, 150)

    coefficient = np.copy(coeff)
    y2 = 0
    # y2 = coefficient[0] + coefficient[1] * graph_x + coefficient[2] * graph_x ** 2
    for index in range(n):
        y2 += coefficient[index] * graph_x ** index
    plt.plot(graph_x, y2, label="Polynomial Regression")
    plt.xlabel("x axis")
    plt.ylabel("y axis")

    plt.legend(loc="best")
    plt.grid()
    plt.show()


def polynomial_regression(a, b):
    x = np.copy(a)
    y = np.copy(b)
    data_size = np.size(a)

    co_matrix = np.zeros((n, n))
    constant_matrix = np.zeros((n, 1))

    for i in range(n):
        for j in range(n):
            co_matrix[i][j] = (np.sum(x ** (i + j)))
    # print(co_matrix)

    for k in range(n):
        constant_matrix[k][0] = np.sum(y * (x ** k))
    # print(constant_matrix)

    result_matrix = gaussianElimination(co_matrix, constant_matrix, True, False)
    return result_matrix


if __name__ == '__main__':
    '''for quadratic equation -> n=3'''
    n = 4

    x_data = np.array([1900.0, 1910.0, 1920.0, 1930.0, 1940.0, 1950.0, 1960.0, 1970.0, 1980.0, 1990.0, 2000.0])
    y_data = np.array([10.3, 13.5, 13.9, 14.2, 11.6, 10.3, 9.7, 9.6, 14.1, 19.8, 31.1])

    # x_data = np.array([80.0, 40.0, -40.0, -120.0, -200.0, -280.0, -340.0])
    # y_data = np.array([0.00000647, 0.00000624, 0.00000572, 0.00000509, 0.00000430, 0.00000333, 0.00000245])

    co_efficients = polynomial_regression(x_data, y_data)
    print("\nThe Co-efficients are : ")
    for i in range(n):
        print("a%d = " % i, end=" ")
        print(co_efficients[i])

    graph(x_data, y_data, co_efficients)
